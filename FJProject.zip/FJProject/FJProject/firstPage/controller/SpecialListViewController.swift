//
//  SpecialListViewController.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/2.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class SpecialListViewController: BaseViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell.init()
        let lable = UILabel.init()
        lable.text = "我的和地方大幅度发大幅度发大幅度发 地方大幅度发辅导辅导辅导费大幅度发的发的辅导费地方地方地方地方地方地方地方大幅度发"
        lable.font = UIFont.systemFont(ofSize: 18)
        lable.numberOfLines = 0
        cell.addSubview(lable)
        lable.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(20)
            make.right.equalToSuperview().offset(-20)
        }
        let width = (SCREEN_WIDTH-80-40)/3
        let rows = ceil(5.0/3)
        let yellowView = UIView.init()
        yellowView.backgroundColor = UIColor.yellow
        cell.addSubview(yellowView)
        yellowView.snp.makeConstraints { (make) in
            make.top.equalTo(lable.snp.bottom).offset(20)
            
            make.left.equalToSuperview().offset(60)
            make.right.equalToSuperview().offset(-20)
            
            
            make.height.equalTo(width*ceil(5.0/3)+10*(ceil(5.0/3)+1.0))
        }
        let row = Int(rows)
        let withds = Int(width)

        for index in 0..<row{
            
            for ind in 0..<3{
                let redView = UIView.init()
                redView.backgroundColor = .red
                redView.frame = CGRect(x: 10+(withds+10)*ind, y: 10+(withds+10)*index,width:withds ,height:withds)
                yellowView.addSubview(redView)
            }
            
            
        }
        
        let lableone = UILabel.init()
        lableone.text = "世界她们的事世界我的和地方大你的大号是激情导辅导辅导费大幅度发的发的辅导费地方地方地方地方地方地方地方"
        lableone.font = UIFont.systemFont(ofSize: 18)
        lableone.numberOfLines = 0
        cell.addSubview(lableone)
        lableone.snp.makeConstraints { (make) in
            make.top.equalTo(yellowView.snp.bottom).offset(40)
            make.left.equalToSuperview().offset(20)
            make.right.equalToSuperview().offset(-20)
            make.bottom.equalToSuperview().offset(-20)
            
        }
//        let lableTwo = UILabel.init()
//        lableTwo.text = ""
//        lableTwo.font = UIFont.systemFont(ofSize: 18)
//        lableTwo.numberOfLines = 0
//        cell.addSubview(lableTwo)
//        lableTwo.snp.makeConstraints { (make) in
//            make.top.equalTo(lableone.snp.bottom).offset(40)
//            make.left.equalToSuperview().offset(20)
//            make.right.equalToSuperview().offset(-20)
//            make.bottom.equalToSuperview().offset(-20)
//        }
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        let tableView = UITableView.init(frame: self.view.frame, style: UITableViewStyle.plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView.init()
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableViewAutomaticDimension
        self.view.addSubview(tableView)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
