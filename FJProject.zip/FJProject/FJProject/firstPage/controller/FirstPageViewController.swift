//
//  FirstPageViewController.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/10/31.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit


class FirstPageViewController: BaseViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDataSourcePrefetching {

    /*快捷菜单数组*/
    lazy var dataList:NSMutableArray = NSMutableArray()
    /**初始化横幅*/
    let bannerImgView = IMGVIEW_WITH_NAME(name: "banner")
    /**当前横幅坐标*/
    var currentFrame:CGRect!
    /**个人查询搜索视图*/
    lazy var textFieldView:SearchBox = SearchBox()
    /**访问量*/
    var visitorVolume:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = .white
        
       
        
        
        self.addBannerImg()
        self.requestSpecialData()
        self.requestVisitorVolume()
       
    }
    /**添加横幅*/
    func addBannerImg() {
        bannerImgView.frame = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 135)
        currentFrame = bannerImgView.frame
        self.view.addSubview(bannerImgView)
    }
    /*添加collectionview*/
    lazy var collectionView:UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout.init()
        flowLayout.scrollDirection = .vertical
        flowLayout.minimumInteritemSpacing = 0;// 水平方向的间距
        flowLayout.minimumLineSpacing = 1; // 垂直方向的间距
        let collectionView = UICollectionView.init(frame:CGRect.zero, collectionViewLayout: flowLayout)
        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = UIColor.clear
        collectionView.dataSource = self
        collectionView.delegate = self
        //if (iOS_VERSION!>=10) {
        collectionView.prefetchDataSource = self
        //}
        //添加collectionview的headview
        collectionView.contentInset = UIEdgeInsetsMake(135, 0, 0, 0);
        let bannerView = UIView.init()
        bannerView.backgroundColor = UIColor.clear
        bannerView.frame = CGRect(x: 0, y: -135, width: SCREEN_WIDTH, height: 135)
        collectionView.addSubview(bannerView)
        /*注册cell和headview，用不同标识符否则滑动collectionview的时候由于复用会导致数据错乱*/
        collectionView.register(SpecialCell.self, forCellWithReuseIdentifier: "specialCell")
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "searchCell")
        collectionView.register(SpecialReusableView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "collectionViewHeader")
        collectionView.register(SpecialReusableView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "nextCollectionViewHeader")
        collectionView.register(SpecialFootView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "collectionViewFooter")
        self.view.addSubview(collectionView)
        collectionView.snp.makeConstraints({ (make) in
            make.bottom.equalToSuperview().offset(-49-SAFE_HEIGHT)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview()
            make.width.equalToSuperview()
        })
        return collectionView
    }()
    /**监听collectionview的滑动距离*/
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
       let distance = scrollView.contentOffset.y
        if distance > -135 {
            bannerImgView.frame = { () -> CGRect in
                var frame = self.currentFrame
                frame?.origin.y = -(distance+135)
                return frame!
            }()
        }else{
            bannerImgView.frame = { () -> CGRect in
                var newFrame = self.currentFrame
                newFrame?.size.height = self.currentFrame.size.height-(distance+135)
                let height = newFrame?.size.height
                newFrame?.size.width = height!/0.36
                let width = newFrame?.size.width
                newFrame?.origin.x = self.currentFrame.origin.x-(width!-self.currentFrame.size.width)/2
                return newFrame!
            }()
        }
    }
    //MARK:请求专项数据
    func requestSpecialData() {
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.cachesDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).last! as NSString
        let specialPath = path.appendingPathComponent("special") as NSString
        if FileManager.default.fileExists(atPath: specialPath as String) {
            
            let data = NSData(contentsOfFile: specialPath as String)
            let dic = NSKeyedUnarchiver.unarchiveObject(with: data! as Data)as! NSDictionary
            let dict = dic["result"] as! NSDictionary
            /**专项数组*/
            let arr = dict["SPFList"] as! NSArray
            for objc in arr{
                let model = SpecialModel()
                model.setValuesForKeys(objc as! [String : Any])
                self.dataList.add(model)
            }
            self.collectionView.reloadData()

        }else{
            var parameters = [String:String]()
            parameters["districtId"] = "6B9E6B70C8784DB381AFAAD16EE82505"
            NetManager.requestData(withUrl: URL("getSPFInfo"), method: .post, parameters: parameters, successBlock: { (response) in
                let data : NSData = NSKeyedArchiver.archivedData(withRootObject: response) as NSData
                data.write(toFile: specialPath as String, atomically: true)
                let dic = response["result"] as! NSDictionary
                /**专项数组*/
                let arr = dic["SPFList"] as! NSArray
                for objc in arr{
                    let model = SpecialModel()
                    model.setValuesForKeys(objc as! [String : Any])
                    self.dataList.add(model)
                }
                self.collectionView.reloadData()
            }) { (error) in
                
            }
        }
    }
    //MARK:请求访问量
    func requestVisitorVolume() {
        let parameters = [String:String]()
        NetManager.requestData(withUrl: "http://fp.fjcz.gov.cn/yscms/cms/fujianpage/getVisitCount.do", method: .post, parameters: parameters, successBlock: { (response) in
            let info = response["result"] as! NSDictionary
            self.visitorVolume = info["allcounts"] as! Int
            self.collectionView.reloadData()
        }) { (error) in
            
        }
    }
    //MARK: - 代理函数
    /*返回secion个数*/
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    /*返回每个secion个数*/
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        if section == 0 {
            return 1
        }
        return dataList.count
    }
    /*设置item大小*/
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0{
            return CGSize(width: SCREEN_WIDTH, height: 80*H)
        }
        return CGSize(width: (SCREEN_WIDTH-3)/4, height: 100*H)
    }
    /*创建collectionviewcell*/
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "searchCell", for: indexPath)
            textFieldView.frame = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: 80*H)
            cell.addSubview(textFieldView)
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "specialCell", for: indexPath) as! SpecialCell
            let model = dataList.object(at: indexPath.row) as! SpecialModel
            cell.setCellWithSpecialModel(model: model)
            return cell
        }
    }
    /*设置每个section的headview大小*/
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: self.view.bounds.width, height: 55*H)
    }
    /*设置每个section的footview大小*/
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize(width: 0, height: 0)
        }
        return CGSize(width: SCREEN_WIDTH, height: 135*H)
    }
    /*创建每个section的headview*/
    public func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if (indexPath.section == 0) {
            let headView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "collectionViewHeader", for: indexPath) as! SpecialReusableView
            headView.query.text = "个人扶贫发放资金查询"
            return headView
        }else{
            if kind == UICollectionElementKindSectionHeader{
                let headView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "nextCollectionViewHeader", for: indexPath) as! SpecialReusableView
                headView.query.text = "按扶贫补助项目查询"
                headView.areaBtn.addTarget(self, action: #selector(showAreas), for: .touchUpInside)
                return headView
            }else{
                let footView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "collectionViewFooter", for: indexPath) as! SpecialFootView
                footView.visitorVolume.text = "总查询量："+"\(self.visitorVolume)"+"次 闽ICP备09021177号"
                return footView
            }
        }
    }
    /**跳转到专项列表*/
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let model = dataList.object(at: indexPath.row) as! SpecialModel
        let svc = SpecialListViewController()
        svc.title = model.JCNAME
        svc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(svc, animated: true)
    }
    public func collectionView(_ collectionView: UICollectionView, prefetchItemsAt indexPaths: [IndexPath])
    {
        
    }
    /**跳转到按地区查询界面*/
    @objc func showAreas() {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
