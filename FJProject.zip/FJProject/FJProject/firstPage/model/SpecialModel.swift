//
//  SpecialModel.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/2.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class SpecialModel: DataModel {

    /*
     "ZXZJBM": "CZJG001",
     "SPFID": "7151CE67688CEE1FE0534165A8C024AC",
     "JCNAME": "扶贫发展（中央）",
     "STPCOUNT": 137,
     "SPFNAME": "中央扶贫发展资金",
     "CODE": "3500201880148",
     "MS": null
     */
    
    /**图片名称*/
    @objc var ZXZJBM:String?
    /**条目id*/
    @objc var SPFID:String?
    /**专项名称*/
    @objc var JCNAME:String?
}
