//
//  SearchBox.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/2.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class SearchBox: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
   lazy var textField = UITextField.init()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let leftView = UILabel.init()
        leftView.frame = CGRect(x: 0, y: 0, width: 15, height: 44*H)
        leftView.backgroundColor = UIColor.clear
        textField.leftView = leftView
        textField.leftViewMode = UITextFieldViewMode.always
        textField.contentVerticalAlignment = UIControlContentVerticalAlignment.center
        textField.placeholder = "请输入姓名或身份证号"
        textField.textColor = COLOR_NORMAL
        textField.layer.masksToBounds = true
        textField.layer.cornerRadius = 4
        textField.layer.borderWidth = 0.3
        textField.layer.borderColor = COLOR_LINE.cgColor
        self.addSubview(textField)
        textField.snp.makeConstraints({ (make) in
            make.center.equalToSuperview()
            make.left.equalToSuperview().offset(30*H)
            make.right.equalToSuperview().offset(-100*H)
            make.height.equalTo(44*H)
        })
        
        let searchBtn = UIButton.init(type: UIButtonType.custom)
        searchBtn.setTitle("查询", for: UIControlState.normal)
        searchBtn.setTitleColor(.white, for: UIControlState.normal)
        searchBtn.titleLabel?.font = Font(15*H)
        searchBtn.backgroundColor = COLOR_NAV
        searchBtn.layer.borderColor = COLOR_LINE.cgColor
        searchBtn.layer.borderWidth = 0.3
        self.addSubview(searchBtn)
        searchBtn.snp.makeConstraints({ (make) in
            make.centerY.equalTo(textField)
            make.left.equalTo(textField.snp.right).offset(-3)
            make.size.equalTo(CGSize(width: 70*H, height: 45*H))
        })

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
