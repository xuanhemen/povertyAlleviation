//
//  SpecialReusableView.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/2.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class SpecialReusableView: UICollectionReusableView {
    
    let colorView = UIView.init()
    let bgView = UIView.init()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = BG_COLOR
        bgView.backgroundColor = .white
        self.addSubview(bgView)
        bgView.snp.makeConstraints({ (make) in
            make.top.equalToSuperview().offset(10)
            make.width.equalToSuperview()
            make.bottom.equalToSuperview().offset(-0.5)
        })
        colorView.backgroundColor = COLOR_NAV
        bgView.addSubview(colorView)
        colorView.snp.makeConstraints({ (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(15*H)
            make.size.equalTo(CGSize(width: 2*H, height: 16*H))
        })
        
    }
    /**查询方式*/
    lazy var query: UILabel = {
        let query = UILabel()
        query.textColor = COLOR_NORMAL
        query.font = FontNormal
        query.sizeToFit()
        bgView.addSubview(query)
        query.snp.makeConstraints({ (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(colorView.snp.right).offset(10*H)
        })
        return query
    }()
    /**按地区查询btn*/
    lazy var areaBtn: UIButton = {
        let areaBtn = UIButton.init(type: .custom)
        areaBtn.setTitle("按地区查询", for: .normal)
        areaBtn.setTitleColor(COLOR_NAV, for: .normal)
        areaBtn.titleLabel?.font = FontNormal
        bgView.addSubview(areaBtn)
        areaBtn.snp.makeConstraints({ (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-10*H)
        })
        return areaBtn
    }()
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
