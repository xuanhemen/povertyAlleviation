//
//  SpecialFootView.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/16.
//  Copyright © 2018 Jianwei Dong. All rights reserved.
//

import UIKit

class SpecialFootView: UICollectionReusableView {
    /**访问量*/
    let visitorVolume = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let frontLine = UILabel()
        frontLine.backgroundColor = COLOR_LINE
        self.addSubview(frontLine)
        frontLine.snp.makeConstraints({ (make) in
            make.top.equalToSuperview().offset(30)
            make.left.equalToSuperview().offset(10)
            make.size.equalTo(CGSize(width: 135, height: 0.3))
        })
        let behindLine = UILabel()
        behindLine.backgroundColor = COLOR_LINE
        self.addSubview(behindLine)
        behindLine.snp.makeConstraints({ (make) in
            make.top.equalToSuperview().offset(30)
            make.right.equalToSuperview().offset(-10)
            make.size.equalTo(CGSize(width: 135, height: 0.3))
        })
        let versionInfo = UILabel()
        versionInfo.text = "版本信息"
        versionInfo.textColor = UIColor.lightGray
        versionInfo.font = UIFont.boldSystemFont(ofSize: 13)
        versionInfo.sizeToFit()
        self.addSubview(versionInfo)
        versionInfo.snp.makeConstraints({ (make) in
            make.top.equalToSuperview().offset(22)
            make.centerX.equalToSuperview()
        })
        let guidance = UILabel()
        guidance.text = "指导单位：福建省纪委监委"
        guidance.textColor = UIColor.lightGray
        guidance.font = Font(13)
        guidance.sizeToFit()
        self.addSubview(guidance)
        guidance.snp.makeConstraints({ (make) in
            make.top.equalTo(versionInfo.snp.bottom).offset(16)
            make.centerX.equalToSuperview()
        })
        let constructionUnit = UILabel()
        constructionUnit.text = "建设单位：福建省财政厅  福建省农业厅"
        constructionUnit.textColor = UIColor.lightGray
        constructionUnit.font = Font(13)
        constructionUnit.sizeToFit()
        self.addSubview(constructionUnit)
        constructionUnit.snp.makeConstraints({ (make) in
            make.top.equalTo(guidance.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
        })
        
        visitorVolume.textColor = UIColor.lightGray
        visitorVolume.font = Font(13)
        visitorVolume.sizeToFit()
        self.addSubview(visitorVolume)
        visitorVolume.snp.makeConstraints({ (make) in
            make.top.equalTo(constructionUnit.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
        })
       
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
