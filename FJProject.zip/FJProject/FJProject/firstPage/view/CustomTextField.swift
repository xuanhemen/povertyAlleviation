//
//  CustomTextField.swift
//  SwiftProject
//
//  Created by Jianwei Dong on 2018/8/20.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class CustomTextField: UITextField {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.tintColor = RGBA(R: 56, G: 152, B: 246, A: 1)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func caretRect(for position: UITextPosition) -> CGRect {
        var originalRect = super.caretRect(for: position)
        originalRect.origin.y = originalRect.origin.y + 2
        originalRect.size.height = (self.font?.lineHeight)!-2
        originalRect.size.width = 2
        return originalRect
        
    }
    
    //控制placeHolder的位置，左右缩20
    override func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        let inset = CGRect(x: bounds.origin.x+70, y: (bounds.origin.y+15)*H, width: bounds.size.width, height: bounds.size.height)
        return inset
        
    }
    //控制显示文本的位置
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        let inset = CGRect(x: bounds.origin.x+70, y: bounds.origin.y, width: bounds.size.width, height: bounds.size.height)
        return inset
    }
    //控制编辑文本的位置
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        let inset = CGRect(x: bounds.origin.x+66, y: bounds.origin.y, width: bounds.size.width, height: bounds.size.height)
        return inset
    }
    //控制左视图位置
    override func leftViewRect(forBounds bounds: CGRect) -> CGRect {
        let inset = CGRect(x: bounds.origin.x+25, y: (bounds.origin.y+13)*H, width: 20*H, height: 20*H)
        return inset
    }
    //控制右视图位置
    override func rightViewRect(forBounds bounds: CGRect) -> CGRect {
        let inset = CGRect(x: bounds.origin.x+30, y: (bounds.origin.y+18)*H, width: 20*W, height: 14*H)
        return inset
    }
    //修改占位符颜色和字体大小
    override func drawPlaceholder(in rect: CGRect) {
        UIColor.orange.set()
        let attrs = NSMutableDictionary()
        attrs[NSAttributedStringKey.foregroundColor] = RGBA(R: 56, G: 152, B: 246, A: 0.3)
        attrs[NSAttributedStringKey.font] = FontNormal
        self.placeholder?.draw(in: rect, withAttributes: attrs as? [NSAttributedStringKey : Any])
        
        
        
    }

    
}
