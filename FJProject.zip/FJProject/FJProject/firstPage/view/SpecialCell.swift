//
//  SpecialCell.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/2.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class SpecialCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    /**专项图片*/
    lazy var imgView: UIImageView = {
        var imgView = UIImageView.init()
        self.addSubview(imgView)
        imgView.snp.makeConstraints({ (make) in
            make.width.equalTo(40*H)
            make.height.equalTo(40*H)
            make.centerX.equalTo(self)
            make.centerY.equalTo(self).offset(-13*H)
            
        })
        return imgView
    }()
    /**专项名称*/
    lazy var specialName: UILabel = {
        let specialName = UILabel()
        specialName.textAlignment = NSTextAlignment.center
        specialName.textColor = COLOR_NORMAL
        specialName.font = Font(14*W)
        specialName.sizeToFit()
        self.addSubview(specialName)
        specialName.snp.makeConstraints({ (make) in
            make.centerX.equalTo(imgView)
            make.top.equalTo(imgView.snp.bottom).offset(7*H)
            make.size.equalTo(CGSize(width: 95*W, height: 30*H))
        })
        return specialName
    }()
    /**是否是中央专项*/
    lazy var distinguishLb: UILabel = {
        let distinguishLb = UILabel()
        distinguishLb.textColor = UIColor.white
        distinguishLb.font = Font(9)
        distinguishLb.textAlignment = NSTextAlignment.center
        distinguishLb.layer.masksToBounds = true
        distinguishLb.layer.cornerRadius = 6
        self.addSubview(distinguishLb)
        distinguishLb.snp.makeConstraints({ (make) in
            make.right.equalTo(imgView).offset(5)
            make.bottom.equalTo(imgView)
            make.size.equalTo(CGSize(width: 25, height: 13))
        })
        return distinguishLb
    }()
    /**赋值cell*/
    func setCellWithSpecialModel(model: SpecialModel) {
        self.imgView.image = UIImage(named: model.ZXZJBM!)
        let string = model.JCNAME?.replacingOccurrences(of: "（中央）", with: "")
        self.specialName.text = string
        if (model.JCNAME?.contains("中央"))! {
            self.distinguishLb.text = "中央"
            self.distinguishLb.backgroundColor = UIColor.red
        }else{
            self.distinguishLb.text = ""
            self.distinguishLb.backgroundColor = UIColor.clear
        }
    }
}
