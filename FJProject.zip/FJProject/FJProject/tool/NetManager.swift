//
//  NetManager.swift
//  SwiftProject
//
//  Created by Jianwei Dong on 2018/8/23.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit
import Alamofire
import SwiftProgressHUD



/*枚举请求方式*/
public enum HttpRequestMethod {
    case post
    case get
}
class NetManager: NSObject {

    /**定义成功和失败的回调*/
    typealias Success = (_ response:NSDictionary) ->Void
    typealias Failure = (_ error:NSError) -> Void

    static func requestData(withUrl:String,method:HTTPMethod,parameters:[String:String],successBlock: @escaping Success,failureBlock: @escaping Failure) {
       
        
        
        /**HUD*/
        SVProgressHUD.show(withStatus: "正在加载")
        SVProgressHUD.setBackgroundColor(UIColor.gray)
        SVProgressHUD.setForegroundColor(UIColor.white)
        /**请求数据*/
        Alamofire.request(withUrl, method: method, parameters: parameters, encoding: URLEncoding.default).responseJSON { (response) in
            
            /**隐藏HUD*/
            SVProgressHUD.dismiss()
            /**请求成功*/
            response.result.ifSuccess {
                if response.result.value != nil {
                    
                    let dic = response.result.value as! NSDictionary
                    successBlock(dic)

                }
            }
            /**请求失败*/
            response.result.ifFailure {
                failureBlock(response.result.error! as NSError)
            }

            
        }
        
        
    }
        
    static func monitorNet()  {
        
        let manager = NetworkReachabilityManager(host: "http://192.168.1.138:8080")
        
        manager?.listener = { status in
            
            
            print("网络状态: \(status)")
            switch (status) {
            case .unknown:
                print("网络异常")
                break;
            case .notReachable:
                // NSLog(@"3G|4G");
                print("没有网络")
                break;
            case .reachable:
                
                print("网络")
                
                break;
                
            }
            
        }
        
        manager?.startListening()//开始监听网络
        
    }
        
        
        
    
    
    
}
