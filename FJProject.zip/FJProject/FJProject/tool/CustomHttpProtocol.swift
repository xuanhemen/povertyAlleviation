//
//  CustomHttpProtocol.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/23.
//  Copyright © 2018 Jianwei Dong. All rights reserved.
//

import UIKit

class CustomHttpProtocol: URLProtocol {

    open override class func canInit(with request: URLRequest) -> Bool{
       return true
    }
}
