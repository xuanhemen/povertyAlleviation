//
//  GenericTableView.swift
//  SwiftProject
//
//  Created by Jianwei Dong on 2018/8/28.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

/**自定义空视图*/
class EmptyView: UIView {
    /**定义空数据类型*/
    enum EmptyDataType {
        /**无数据*/
        case EmptyNoDataType
        /**链接超时*/
        case EmptyNoNetType
    }
    override init(frame: CGRect) {
        super.init(frame: frame)

    }
    /**重构初始化方法*/
    init(frame: CGRect,type:EmptyDataType) {
        super.init(frame: frame)
        /**初始化枚举，根据传进来的类型创建不同状况的视图*/
        var emptyType = EmptyDataType.EmptyNoNetType
        emptyType = type
        switch emptyType {
        case .EmptyNoDataType:
            self.emptyImgView.image = UIImage(named: "noData")
            self.emptyLable.text = "EmptyData!"
            break
        case .EmptyNoNetType:
            self.emptyImgView.image = UIImage(named: "noNetwork")
            self.emptyLable.text = "Network problems!"
            break

        }
    }
    /**加载图片*/
    lazy var emptyImgView: UIImageView = {
        let emptyImgView = UIImageView()
        self.addSubview(emptyImgView)
        emptyImgView.snp.makeConstraints({ (make) in
            make.centerY.equalTo(self).offset(-45*H)
            make.centerX.equalTo(self)
        })
        return emptyImgView
    }()
    /**加载文字*/
    lazy var emptyLable: UILabel = {
        let emptyLable = UILabel()
        emptyLable.textColor = RGBA(R: 220, G: 220, B: 220, A: 1)
        emptyLable.font = UIFont.boldSystemFont(ofSize: 20*H)
        self.addSubview(emptyLable)
        emptyLable.snp.makeConstraints({ (make) in
            make.centerX.equalTo(self)
            make.top.equalTo(self.emptyImgView.snp.bottom).offset(20*H)
        })
        return emptyLable
    }()

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
//MARK: - tableView
class GenericTableView: UITableView,UITableViewDelegate,UITableViewDataSource {

    /**声明类型*/
    typealias SelectCell = (IndexPath) -> Void
     /**声明类型*/
    typealias CreateCell = (IndexPath) -> UITableViewCell
    /**点击cell回调*/
    var selectedCell:SelectCell? = nil
    /**创建cell回调*/
    var createCell:CreateCell? = nil
    typealias DownFresh = () -> Void
    typealias PullFresh = () -> Void
    /**rows*/
    var dataArr = NSMutableArray()
    /**cell高度*/
    var height:CGFloat = 0
    /**空视图*/
    var emptyView:EmptyView?
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return self.dataArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return self.height
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        return self.createCell!(indexPath)
                    
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.selectedCell!(indexPath)
    }
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: style)
        
    }
    init(frame: CGRect, style: UITableViewStyle,dataArr:NSMutableArray,height:CGFloat,cell:@escaping CreateCell,selectedCell:@escaping SelectCell) {
        super.init(frame: frame, style: style)
        self.dataSource = self
        self.delegate = self
        self.dataArr = dataArr
        self.height = height
        self.createCell = cell
        self.selectedCell = selectedCell
        self.tableFooterView = UIView()
        if self.dataArr.count == 0 {
           self.loadEmptyDataView()
        }
        
    }
    /**加载无数据视图*/
    func loadEmptyDataView()
    {
        emptyView = EmptyView.init(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: SCREEN_HEIGHT-100*H), type: EmptyView.EmptyDataType.EmptyNoDataType)
        self.addSubview(emptyView!)

    }
    /**加载请求超时视图*/
    func loadNoNetView()
    {

    }
    
     func addDropDownRefresh(downFresh:@escaping DownFresh) {
        
        let head = MJRefreshNormalHeader.init {
            downFresh()
        }
        head?.stateLabel.textColor = UIColor.lightGray
        head?.lastUpdatedTimeLabel.textColor = UIColor.lightGray
        self.mj_header = head


    }
    func addPullOnLoading(pullFresh:@escaping PullFresh) {
        
        let foot = MJRefreshAutoNormalFooter.init {
            pullFresh()
        }
        foot?.stateLabel.text = "加载更多"
        foot?.setTitle("", for: MJRefreshState.idle)
        foot?.setTitle("正在加载更多", for: MJRefreshState.refreshing)
        foot?.setTitle("没有更多数据了", for: MJRefreshState.noMoreData)
        foot?.stateLabel.font = UIFont.boldSystemFont(ofSize: 16*H)
        foot?.stateLabel.textColor = .lightGray
        self.mj_footer = foot

    }
   /*遍历构造器
    convenience init(frame:CGRect,style:UITableViewStyle,rowCount:Int,cellHeight:CGFloat,cell:@escaping CreateCell,selectedCell:@escaping SelectCell) {
        
        self.init()
        self.dataSource = self
        self.delegate = self
        self.rows = rowCount
        self.height = cellHeight
        print(self.height)
        self.createCell = cell
        self.selectedCell = selectedCell
       
        
    }
   */
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
