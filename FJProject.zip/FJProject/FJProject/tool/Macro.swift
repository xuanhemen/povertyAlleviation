//
//  Macro.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/10/31.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import Foundation
import UIKit
import SnapKit
import Alamofire



/*url*/
func URL(_ path:String) -> String
{
    return "http://fp.fjcz.gov.cn/yscms/app/"+path+".do"
}
/*IMSI码*/
let IMSI = UIDevice.current.identifierForVendor?.uuidString
/*tokenid*/
let TOKENID = UserDefaults.standard.string(forKey: "tokenID")
/*屏幕宽度*/
let SCREEN_WIDTH = UIScreen.main.bounds.size.width
/*屏幕高度*/
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height
/*体统版本*/
let iOS_VERSION = Int(UIDevice.current.systemVersion)

/*颜色RGBA*/
func RGBA(R:CGFloat,G:CGFloat,B:CGFloat,A:CGFloat) -> UIColor {
    let color:UIColor = UIColor.init(red: R/255, green: G/255, blue: B/255, alpha: A)
    return color
}
/*背景色*/
let BG_COLOR = RGBA(R: 240,G: 240,B: 240,A: 1)
/*字体颜色*/
let COLOR_NORMAL = RGBA(R: 50,G: 50,B: 50,A: 1)
/*灰色字体颜色*/
let COLOR_LIGHT = RGBA(R: 100,G: 100,B: 100,A: 1)
/*线颜色*/
let COLOR_LINE = RGBA(R: 230,G: 230,B: 230,A: 1)
/*导航栏颜色*/
let COLOR_NAV =  RGBA(R: 208, G: 70, B: 85, A: 1)


/*安全高度*/
let SAFE_HEIGHT = CGFloat(SCREEN_HEIGHT >= 812 ?34:0)

func IS_IPHONE() -> Bool {
    return UIDevice.current.userInterfaceIdiom == .phone
}

let YYISiPhoneX = UIScreen.main.bounds.size.width >= 375.0 && UIScreen.main.bounds.size.height >= 812.0 && IS_IPHONE()
/*导航栏高度*/
let NAVBAR_HEIGHT = UIScreen.main.bounds.size.height>=812.0 ?88:64


func SIZE_EQUAL(width:CGFloat,height:CGFloat) -> Bool {
    
    return CGSize(width: width, height: height).equalTo(UIScreen.main.bounds.size)
}
/*适配(414.0, 736.0)*/
let W:CGFloat = CGFloat(UIScreen.main.bounds.size.width/414.0)
let H:CGFloat = CGFloat(UIScreen.main.bounds.size.height/736.0)
func RECT_MAKE(x:CGFloat,y:CGFloat,width:CGFloat,height:CGFloat) -> CGRect
{
    return CGRect(x: x*W, y: y*H, width: width*W, height: height*H)
    
}
/*创建imageview*/
func IMGVIEW_WITH_NAME(name:String) -> UIImageView {
    
    return UIImageView.init(image: UIImage(named: name))
}
/*user地方*/
let USER_DEFAULTS = UserDefaults.standard
/**正常字体大小*/
let FontNormal = UIFont.systemFont(ofSize: 16*H)
/**设置字体大小*/
func Font(_ font:CGFloat) -> UIFont {
    return UIFont.systemFont(ofSize: font*H)
}


