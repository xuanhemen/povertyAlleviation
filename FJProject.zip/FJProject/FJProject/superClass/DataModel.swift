//
//  DataModel.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/11/2.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class DataModel: NSObject {

    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    override func value(forUndefinedKey key: String) -> Any? {
        return NSNull()
    }
}
