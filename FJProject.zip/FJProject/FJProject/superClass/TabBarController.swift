//
//  TabBarController.swift
//  FJProject
//
//  Created by Jianwei Dong on 2018/10/31.
//  Copyright © 2018年 Jianwei Dong. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let fvc = FirstPageViewController()
        fvc.navigationItem.title = "首页"
        let nfvc = NavViewController.init(rootViewController: fvc)
        fvc.tabBarItem.title = "首页"
        fvc.tabBarItem.image = UIImage(named: "首页")
        fvc.tabBarItem.selectedImage = UIImage(named: "tabbar_icon_home_active")

        let mvc = ManagerViewController()
        mvc.navigationItem.title = "管理办法"
        let nmvc = NavViewController.init(rootViewController: mvc)
        mvc.tabBarItem.title = "管理办法"
        mvc.tabBarItem.image = UIImage(named: "管理办法")
        mvc.tabBarItem.selectedImage = UIImage(named: "tabbar_icon_lanmu_active")
        
        let vvc = VillageViewController()
        vvc.navigationItem.title = "村务公开"
        let nvvc = NavViewController.init(rootViewController: vvc)
        vvc.tabBarItem.title = "村务公开"
        vvc.tabBarItem.image = UIImage(named: "村务公开")
        vvc.tabBarItem.selectedImage = UIImage(named: "tabbar_icon_cunwu_active")
        
//
        let mivc = MineViewController()
        mivc.navigationItem.title = "我的"
        let nmivc = NavViewController.init(rootViewController: mivc)
        mivc.tabBarItem.title = "我的"
        mivc.tabBarItem.image = UIImage(named: "我的")
        mivc.tabBarItem.selectedImage = UIImage(named: "tabbar_icon_my_active")

        self.addChildViewController(nfvc)
        self.addChildViewController(nmvc)
        self.addChildViewController(nvvc)
        self.addChildViewController(nmivc)

        self.tabBar.tintColor = COLOR_NAV
        self.tabBar.barTintColor = .white
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
